const express = require('express')
const app = express();
const port = 8000;
const cors = require('cors');
const mqtt=require('mqtt');
const bodyParser = require('body-parser');

const client = mqtt.connect('mqtt://broker.hivemq.com')
app.use(cors());
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
let connectedStatus = false;
client.on("connect",function(){	
  // console.log("connected");
  connectedStatus= true;
});

client.on('message',function(topic, message, packet){
	// console.log("message is "+ message);
	// console.log("topic is "+ topic);
});

client.on("error",function(error){
  console.log("Can't connect" + error);
  connectedStatus = false;
  process.exit(1);
});

var topic="test/dummy/topic";
var message="test message";



app.get('/test/', (req, res) => {
  let connectedState = '';
  let topicValue;
  
  if (connectedStatus==true){
    // let temp = client.publish(topic, message);
    // console.log(temp);
    connectedState = 'RUNNING';
    topicValue = topic;
  } else {
    connectedState = 'STOPPED';
    topicValue = topic;
  }
  let responseData = [{
    "status" : connectedState,
    "topic" : topicValue
  }];
  res.send(responseData);
});

app.post('/test1/', (req, res) => {
  // console.log(JSON.stringify(req.body.params.updates[0].value));
  let inputParam = JSON.stringify(req.body.params.updates[0].value).replace('"', '').replace('"','');
  if(inputParam === "START") {
    let temp = client.subscribe(topic,{qos:1});
    // console.log(JSON.stringify(temp.options.hostname));
    res.send(Math.random().toString()+ '  ' + message);
  } else if(inputParam === "STOP"){
    res.send("Data Stopped");
  } else {
    res.send("Null");
  }
  // res.send('Hello New World!')
});

app.listen(port, () => {
  console.log(`App listening on port ${port}!`)
});