import { Component } from '@angular/core';
import { DataService } from './data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  postVal = 'START';
  getData: any;
  postData: any;
  startRad: any;
  stopRad: any;
  constructor(private dataService: DataService) {}
  getApiData() {
    this.dataService.getApiData()
      .subscribe((res: any) => this.getData = res);
    // alert(this.getData);
  }
  postApiData() {
    this.dataService.postApiData(this.postVal)
      .subscribe((res: any) => {this.postData = res;console.log(res);});
  }

  startPost() {
    this.postVal = "START";
    this.postApiData();
  }

  stopPost() {
    this.postVal = "STOP";
    this.postApiData();
  }
}
